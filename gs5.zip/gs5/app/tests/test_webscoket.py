import pytest
from django.test import TestCase, override_settings
from django.urls import path
from rest_framework.authtoken.models import Token
from channels.routing import URLRouter
from channels.testing import WebsocketCommunicator

from app.consumers import CustomWebsocketConsumer
from app.models import User

TEST_CHANNEL_LAYERS = {
    'default': {
        'BACKEND': 'channels_redis.core.RedisChannelLayer',
        'CONFIG': {
            "hosts": [('127.0.0.1', 6379)],
        },
    },
}


@pytest.mark.django_db
@pytest.mark.asyncio
class TestWebSockets(TestCase):
    databases = '__all__'

    def setUp(self):
        """
        setup dummay users to check test cases.
        """
        
        self.user_1 = User.objects.create_user('sam', 'sam@gmail.com', 'password@123')
        self.token_1 = Token.objects.create(user=self.user_1 )
        self.token_1.save()

        self.user = User.objects.create_user('saurabh', 'saurabh@gmail.com', 'password@123')
        self.token = Token.objects.create(user=self.user)
        self.token.save()

    async def test_can_connect_to_server(self):
        """
        Test to verify that a socket connection, WebsocketConsumer adds and 
        removes channels from groups.
        """
        with override_settings(CHANNEL_LAYERS=TEST_CHANNEL_LAYERS):
            group_name = "indian"
            application = URLRouter([path('ws/sc/<str:groupname>/', CustomWebsocketConsumer().as_asgi()), ])
            communicator = WebsocketCommunicator(application, f'/ws/sc/{group_name}/')
            communicator.scope["user"] = self.user
            connected, _ = await communicator.connect()
            assert connected
            await communicator.disconnect()
        
    # async def test_can_send_and_receive_messages_from_one_to_one_message(self):
    #     with override_settings(CHANNEL_LAYERS=TEST_CHANNEL_LAYERS):
    #         group_name = "sam"
    #         application = URLRouter([path('ws/sc/<str:groupname>/', CustomWebsocketConsumer().as_asgi()), ])
    #         communicator = WebsocketCommunicator(application, f'/ws/sc/{group_name}/')
    #         communicator.scope["user"] = self.user_1
    #         connected, _ = await communicator.connect()
    #         assert connected
    #         message = {
    #                 "content": "Hello From postman API from admin to sam",
    #                 "message_type": "ONE_TO_ONE"
    #             }
    #         await communicator.send_json_to(message)
    #         response = await communicator.receive_json_from()
    #         assert response == json.dumps(message)
    #         await communicator.disconnect()
    

    async def test_can_send_and_receive_messages_from_group_message(self):
        with override_settings(CHANNEL_LAYERS=TEST_CHANNEL_LAYERS):
            group_name = "indian"
            application = URLRouter([path('ws/sc/<str:groupname>/', CustomWebsocketConsumer().as_asgi()), ])
            communicator = WebsocketCommunicator(application, f'/ws/sc/{group_name}/')
            communicator.scope["user"] = self.user
            connected, _ = await communicator.connect()
            assert connected
            message = {
                    "content": "Hello From postman API from admin to sam",
                    "message_type": "GROUP",
                    "participants":[str(self.user_1.id)]
                }
            await communicator.send_json_to(message)
            response = await communicator.receive_json_from()
            self.assertEqual(None, response['error'])