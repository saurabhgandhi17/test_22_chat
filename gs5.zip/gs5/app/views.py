from unicodedata import name
from django.shortcuts import render
# from .models import Group, Chat


def index(request, group_name):
    return render(request, 'app/index.html', {'group_name': group_name, "chats": ''})
