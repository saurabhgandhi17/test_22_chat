from django.contrib import admin
from .models import Attachments, OneToOneMessage, OneToOneGroup,User,GroupInfo,GroupMessage


@admin.register(User)
class UserModelAdmin(admin.ModelAdmin):
    list_display = ['id', 'username', 'email', 'first_name']


@admin.register(Attachments)
class AttachmentsModelAdmin(admin.ModelAdmin):
    readonly_fields = ('upload_date',)
    list_display = ['id', 'uploaded_by', 'file', 'upload_date','created_at','updated_at']
    date_hierarchy = 'upload_date'


@admin.register(OneToOneGroup)
class OneToOneGroupModelAdmin(admin.ModelAdmin):
    readonly_fields = ('created_at',)
    list_display = ['id','channel_name','sender', 'receiver', 'created_at']
    fields = ['sender', 'receiver']
    date_hierarchy = 'created_at'


@admin.register(OneToOneMessage)
class OneToOneMessageModelAdmin(admin.ModelAdmin):
    readonly_fields = ('created_at',)
    list_display = ['id', 'content', 'sender','receiver', 'group','uploaded_files','message_type', 'message_format','is_read', 'is_delete','created_at']
    date_hierarchy = 'created_at'


@admin.register(GroupInfo)
class GroupInfoModelAdmin(admin.ModelAdmin):
    readonly_fields = ('created_at',)
    list_display = ['id', 'name','created_at','updated_at']
    date_hierarchy = 'created_at'


@admin.register(GroupMessage)
class GroupMessageModelAdmin(admin.ModelAdmin):
    readonly_fields = ('created_at',)
    list_display = ['id','content','sender','members','files','group','message_type','message_format','is_delete','created_at','updated_at']
    date_hierarchy = 'created_at'