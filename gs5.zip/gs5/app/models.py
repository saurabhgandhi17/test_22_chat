import uuid
from django.db import models
from django.db.models import Q
from django.utils.translation import gettext_lazy as _
from django.contrib.auth.models import AbstractBaseUser
from typing import Optional, Any

from user.models import User

def upload_to(instance, filename):
    return f"attchments/{instance.message_type}/{filename}"

class BaseModel(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    class Meta:
    	abstract = True


class BaseTimestampedModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class ChatCommonFieldsModelMixin(BaseTimestampedModel):
    MESSAGE_TYPE = (
        ('ONE_TO_ONE', 'one_to_one'),
        ('GROUP', 'group'),
    )

    MESSAGE_CONTENT_FORMAT = (
        ('TEXT', 'text'),
        ('AUDIO', 'audio'),
        ('VIDEO', 'video'),
        ('FILE', 'file'),
        ('IMAGE', 'image'),
    )

    content = models.TextField(verbose_name=_("Text"), blank=False, null=True)
    message_type = models.CharField(max_length=10, choices=MESSAGE_TYPE, default="one_to_one")
    message_format = models.CharField(max_length=10, choices=MESSAGE_CONTENT_FORMAT, default="text")
    is_delete = models.BooleanField(default=False)

    class Meta:
        abstract = True

    
class Attachments(BaseModel,BaseTimestampedModel):
    uploaded_by = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name=_("Uploaded_by"), related_name='uploaded_by', db_index=True)
    file = models.FileField(verbose_name=_("File"), blank=False, null=False, upload_to=upload_to)
    upload_date = models.DateTimeField(auto_now_add=True, verbose_name=_("Upload date"))
    message_type = models.CharField(max_length=10)

    def __str__(self):
        return str(self.file.name)


class OneToOneGroup(BaseModel,BaseTimestampedModel):
    channel_name = models.CharField(max_length=255, blank=False)
    sender = models.ForeignKey(User, related_name='one_to_one_sender',on_delete=models.CASCADE, verbose_name=_("sender"))
    receiver = models.ForeignKey(User, related_name='one_to_one_receiver',on_delete=models.CASCADE, verbose_name=_("receiver"))

    class Meta:
        unique_together = (('sender', 'receiver'), ('receiver', 'sender'))
        verbose_name = _("OneToOneGroup")
        verbose_name_plural = _("OneToOneGroups")

    def __str__(self) -> str:
        return str(self.id)

    @staticmethod
    def conversation_exists(u1: AbstractBaseUser, u2: AbstractBaseUser,*args) -> Optional[Any]:
        instance = OneToOneGroup.objects.filter(Q(sender=u1, receiver=u2) | Q(sender=u2, receiver=u1)).first()
        OneToOneMessage.objects.filter(pk=str(args[0])).update(group=instance)
        return instance

    @staticmethod
    def create_if_not_exists(u1: AbstractBaseUser, u2: AbstractBaseUser,*args):
        res = OneToOneGroup.conversation_exists(u1, u2,*args)
        if not res:
            instance = OneToOneGroup.objects.create(sender=u1, receiver=u2,channel_name=f"Room_{u2.id}")
            OneToOneMessage.objects.filter(pk=str(args[0])).update(group=instance)


class OneToOneMessage(BaseModel,ChatCommonFieldsModelMixin):
    sender = models.ForeignKey(User, related_name='from_sender', on_delete=models.CASCADE, verbose_name=_("Sender"))
    receiver = models.ForeignKey(User, related_name='to_receiver', on_delete=models.CASCADE, verbose_name=_("Receiver"))
    group = models.ForeignKey(OneToOneGroup, related_name='channel', on_delete=models.CASCADE, verbose_name=_("Group"),null=True,blank=True)
    file = models.ManyToManyField(Attachments,related_name='message', verbose_name=_("Attachment"), blank=True, null=True)
    is_read = models.BooleanField(default=False)

    def save(self, *args, **kwargs):
        super(OneToOneMessage, self).save(*args, **kwargs)
        OneToOneGroup.create_if_not_exists(self.sender, self.receiver,self.id)

    def uploaded_files(self):
        return ",".join([str(files) for files in self.file.all()])

    class Meta:
        ordering = ('-created_at',)
        verbose_name = "OneToOneMessage"
        verbose_name_plural = "OneToOneMessages"

    def __str__(self):
        return str(self.id)
    

class GroupInfo(BaseModel,BaseTimestampedModel):
    name = models.CharField(max_length=255, blank=False, verbose_name=_("Group Name"))
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name=_("created by"))

    class Meta:
        ordering = ('-created_at',)
        verbose_name = _("GroupInfo")
        verbose_name_plural = _("GroupInfos")
    
    def __str__(self) -> str:
        return str(self.name)
    

class GroupMessage(BaseModel,ChatCommonFieldsModelMixin):
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name="grp_senders")
    participants = models.ManyToManyField(User, related_name="grp_participants")
    group = models.ForeignKey(GroupInfo , on_delete=models.CASCADE,related_name="grp_group_name",null=True, blank=True)
    file = models.ManyToManyField(Attachments,related_name='grp_attachments', verbose_name=_("Attachment"), blank=True, null=True)

    def files(self):
        return ",".join([str(files) for files in self.file.all()])
    
    def members(self):
        return ",".join([str(participants) for participants in self.participants.all()])
    
    class Meta:
        ordering = ('-created_at',)
        verbose_name = _("GroupMessage")
        verbose_name_plural = _("GroupMessages")

    def __str__(self) -> str:
        return str(self.id)