import json
from django.urls import reverse
from rest_framework.test import APITestCase

from user.models import User


class UserRegistrationAPIViewTestCase(APITestCase):
    url = reverse("register")

    def test_user_registration(self):
        """
        Test to verify that a post call with user valid data
        """
        user_data = {
            "username": "saurabh",
            "email": "saurabh@gmail.com",
            "password": "password"
        }
        response = self.client.post(self.url, user_data)
        self.assertEqual(201, response.status_code)
        self.assertTrue("token" in json.loads(response.content))


    def test_unique_username_validation(self):
        """
        Test to verify that a post call with already exists username
        """
        user_data_1 = {
            "username": "saurabh",
            "email": "saurabh@gmail.com",
            "password": "password",
        }
        response = self.client.post(self.url, user_data_1)
        self.assertEqual(201, response.status_code)

        user_data_2 = {
            "username": "saurabh",
            "email": "saurabh@gmail.com",
            "password": "password",
        }
        response = self.client.post(self.url, user_data_2)
        self.assertEqual(400, response.status_code)


class UserLoginAPIViewTestCase(APITestCase):
    url = reverse("login")

    def setUp(self):
        self.username = "saurabh"
        self.email = "saurabh@gmail.com"
        self.password = "password"
        self.user = User.objects.create_user(self.username, self.email, self.password)


    def test_authentication_without_password(self):
        """
        Test to verify that a post call with username and without password
        """
        response = self.client.post(self.url, {"username": "saurabh"})
        self.assertEqual(400, response.status_code)


    def test_authentication_with_wrong_password(self):
        """
        Test to verify that a post call with username and wrong password
        """
        response = self.client.post(self.url, {"username": self.username, "password": "I_know"})
        self.assertEqual(400, response.status_code)


    def test_authentication_with_valid_data(self):
        """
        Test to verify that a post call with username and password and return the token
        """
        response = self.client.post(self.url, {"username": self.username, "password": self.password})
        self.assertEqual(200, response.status_code)
        self.assertTrue("token" in json.loads(response.content))
